#coding:utf-8
import cv2
import hand_gesture_control_dcc

cap= cv2.VideoCapture(0)  # 创建了一个名为 cap 的视频捕获对象，它打开了默认的摄像头（通常是编号为 0 的摄像头）
cv2.namedWindow('main')  # 创建了一个名为 'main' 的窗口，用于显示摄像头捕获的图像。

while(cap.isOpened()):  # 进入一个循环，只要摄像头处于打开状态，就会一直执行以下代码。
    ret,img=cap.read() # 从摄像头获取一帧图像，并将其存储在变量 img 中。ret 是一个布尔值，表示是否成功获取到图像。
    # 开关输入信号：如果flase表示不拍照，true表示拍照
    take_photo_single=False


    if ret :  # 如果成功获取到图像（ret 为 True）
        cv2.imshow('main', img)  # 将图像显示在名为 'main' 的窗口中。
        k = cv2.waitKey(1) & 0xff  # 等待用户按下键盘上的按键，并将按键的 ASCII 值存储在变量 k 中。
        if k==ord('q') or take_photo_single: # 如果用户按下 q 键或者 take_photo_single 为 True，执行以下代码
            # 这里可以接入红外和手势识别的设计
            cv2.imwrite('cc.jpg',img) # 将当前图像保存为名为 'cc.jpg' 的文件
            break;

        # 手势识别传入识别的指令序号1 2 3 4 5
        # 指令识别主要实现5个功能： 1： 拍照（读取当前页面）   2： 加速播放   3 ： 中止当前进程
        #  4 ： 减速播放    5 ： 关机摄像头
        # （这里拍照手势识别的部分  会对此产生中断）

cap.release() # 释放摄像头资源

cv2.destroyAllWindows() # 关闭窗口
