import requests

base_url = "https://one.aihelpu.top"

access_token = "sk-31ey5PxhYP2q3AfEdF4F3485c4086965d6e69Da431024"

def send_post_request(endpoint, data, access_token):
    url = base_url + endpoint
    headers = {
        "Authorization" : f"Breaer {access_token}",
        "Content-Type" : "application/json",
    }
    response = requests.post(url, headers=headers, json=data)
    return response

def generate_text(prompt):  ### 当然可以变换输入模型
    data = {
        "model": "gpt-3.5-turbo",
        "message": [
            {"role": "system", "content":"u r a helpful assistant"},  # 初始化模型
            {"role": "user", "content": prompt}
        ]
    }

    response = send_post_request("/v1/chat/completions", data, access_token).json()
    print(response)
    return response["choices"][0]["message"]["content"]


