import hand_gesture_control_dcc
import capture_photo
import pyttsx3
import photo_to_text
import os
from pydub import AudioSegment  # 语音处理库
from openai_gpt_api import generate_text
from photo_to_text import get_file_content




def main():
    ### gpt-api的调用部分
    dc = get_file_content("dc.txt")
    prompt = dc  # 传递字符串，用作GPT的调用
    data = generate_text(prompt)
    print(data)

    def text_to_speech(text):
        # 初始化文本到语音引擎
        engine = pyttsx3.init()
        # 设置语速（可选）
        engine.setProperty("rate", 150)  # 调整语速，值越大语速越快  默认是1.5倍速
        # 将文本转换成语音并播放
        engine.say(text)
        engine.runAndWait()

    # 示例：调用 generate_text 函数生成文本
    # prompt = ""
    generated_text = generate_text(prompt)

    # 将生成的文本转换成语音并播放
    text_to_speech(generated_text)

    # 手势识别传入识别的指令序号1 2 3 4 5
    # 指令识别主要实现5个功能： 1： 拍照（读取当前页面）   2： 加速(源文件2.1倍速)播放   3 ： 加速（源文件1.5倍速播放）
    # 4 ： 减速（原文件0.75倍速）播放    5 ： 恢复正常速度播放  6: 关机摄像头中止当前进程   7: 调用gpt进行交互环节

    # （这里拍照手势识别的部分  会对此产生中断）
    if (gesture_output_response == 1){  # 这里的gesture_output_response是用来接受手势识别传回来的结果
        if  ret:
            cv2.imshow('main', img)  # 将图像显示在名为 'main' 的窗口中。
            k = cv2.waitKey(1) & 0xff  # 等待用户按下键盘上的按键，并将按键的 ASCII 值存储在变量 k 中。
            if k==ord('q') or take_photo_single: # 如果用户按下 q 键或者 take_photo_single 为 True，执行以下代码
                # 这里可以接入红外和手势识别的设计
                cv2.imwrite('dc.jpg',img) # 将当前图像保存为名为 'cc.jpg' 的文件
                break;
    }

    if(gesture_output_response == 2){
        def check_audio_exists(audio_path):
            return os.path.exists(audio_path)
        # 用法示例
        audio_path = "dccc.mp3"
        # if check_audio_exists(audio_path):
            # print(f"音频文件 {audio_path} 存在。"
            def check_audio_exists(audio_path):
                try:
                    audio = AudioSegment.from_file(audio_path)
                    return True
                except FileNotFoundError:
                    return False
            # 用法示例
            # audio_path = "dccc.mp3"

            if check_audio_exists(audio_path):
                print(f"音频文件 {audio_path} 存在。")  # 调参用的
            else:
                break



            # 加载音频文件
            audio = AudioSegment.from_file("dccc.mp3")

            # 改变播放速度（2.1 倍）
            new_speed = 2.1
            changed_audio = audio.speedup(playback_speed=new_speed)

            # 保存新的音频文件
            changed_audio.export("dcc_faster_2.1.mp3", format="，mp3")


        # else:
            # break


            ## 同时 需要把新导入的音频传给api！
            photo_to_text.get_file_content=("dcc_faster_2.1.mp3")

    }

    if (gesture_output_response == 3){

        audio_path = "dccc.mp3"
        def check_audio_exists(audio_path):
            return os.path.exists(audio_path)

        # 加载音频文件
        audio = AudioSegment.from_file("dccc.mp3")

        # 改变播放速度（1.5 倍）
        new_speed = 1.5
        changed_audio = audio.speedup(playback_speed=new_speed)

        # 保存新的音频文件
        changed_audio.export("dcc_faster_1.5.mp3", format="，mp3")
    photo_to_text.get_file_content=("dcc_faster_1.5.mp3")
    }

    if (gesture_output_response == 4){

        audio_path = "dccc.mp3"


        def check_audio_exists(audio_path):
            return os.path.exists(audio_path)


        # 加载音频文件
        audio = AudioSegment.from_file("dccc.mp3")

        # 改变播放速度（0.75倍）
        new_speed = 0.75
        changed_audio = audio.speedup(playback_speed=new_speed)

        # 保存新的音频文件
        changed_audio.export("dcc_slower_0.75.mp3", format="，mp3")
        photo_to_text.get_file_content=("dcc_faster_0.75.mp3")
    }

    if (gesture_output_response == 5){

        audio_path = "dccc.mp3"
        photo_to_text.get_file_content=("dccc.mp3")
    }

    if (gesture_output_response == 6){
        cap.release()  # 释放摄像头资源
        cv2.destroyAllWindows()  # 关闭窗口
        exit()  # 彻底退出程序
    }

    ### 再接受红外得到的指令，红外的指令与之相同
    # 红外识别传入识别的指令序号1 2 3 4 5
    # 指令识别主要实现8个功能： 1： 拍照（读取当前页面）   2： 加速(源文件2.1倍速)播放   3 ： 加速（源文件1.5倍速播放）
    # 4 ： 减速（原文件0.75倍速）播放    5 ： 恢复正常速度播放  6: 关机摄像头中止当前进程
    # 电源键： 树莓派开机/关机

    ### 用output_response接受红外识别到的字符串

    if (output_response == 1){  # 这里的gesture_output_response是用来接受手势识别传回来的结果
        if  ret:
            cv2.imshow('main', img)  # 将图像显示在名为 'main' 的窗口中。
            k = cv2.waitKey(1) & 0xff  # 等待用户按下键盘上的按键，并将按键的 ASCII 值存储在变量 k 中。
            if k==ord('q') or take_photo_single: # 如果用户按下 q 键或者 take_photo_single 为 True，执行以下代码
                # 这里可以接入红外和手势识别的设计
                cv2.imwrite('dc.jpg',img) # 将当前图像保存为名为 'cc.jpg' 的文件
                break;
    }

    if(output_response == 2){
        def check_audio_exists(audio_path):
            return os.path.exists(audio_path)
        # 用法示例
        audio_path = "dccc.mp3"
        # if check_audio_exists(audio_path):
            # print(f"音频文件 {audio_path} 存在。"
            def check_audio_exists(audio_path):
                try:
                    audio = AudioSegment.from_file(audio_path)
                    return True
                except FileNotFoundError:
                    return False
            # 用法示例
            # audio_path = "dccc.mp3"

            if check_audio_exists(audio_path):
                print(f"音频文件 {audio_path} 存在。")  # 调参用的
            else:
                break



            # 加载音频文件
            audio = AudioSegment.from_file("dccc.mp3")

            # 改变播放速度（2.1 倍）
            new_speed = 2.1
            changed_audio = audio.speedup(playback_speed=new_speed)

            # 保存新的音频文件
            changed_audio.export("dcc_faster_2.1.mp3", format="，mp3")


        # else:
            # break


            ## 同时 需要把新导入的音频传给api！
            photo_to_text.get_file_content=("dcc_faster_2.1.mp3")

    }

    if (output_response == 3){

        audio_path = "dccc.mp3"
        def check_audio_exists(audio_path):
            return os.path.exists(audio_path)

        # 加载音频文件
        audio = AudioSegment.from_file("dccc.mp3")

        # 改变播放速度（1.5 倍）
        new_speed = 1.5
        changed_audio = audio.speedup(playback_speed=new_speed)

        # 保存新的音频文件
        changed_audio.export("dcc_faster_1.5.mp3", format="，mp3")
    photo_to_text.get_file_content=("dcc_faster_1.5.mp3")
    }

    if (output_response == 4){

        audio_path = "dccc.mp3"
        def check_audio_exists(audio_path):
            return os.path.exists(audio_path)


        # 加载音频文件
        audio = AudioSegment.from_file("dccc.mp3")

        # 改变播放速度（0.75倍）
        new_speed = 0.75
        changed_audio = audio.speedup(playback_speed=new_speed)

        # 保存新的音频文件
        changed_audio.export("dcc_slower_0.75.mp3", format="，mp3")
        photo_to_text.get_file_content=("dcc_faster_0.75.mp3")
        break
    }

    if (output_response == 5){

        audio_path = "dccc.mp3"
        photo_to_text.get_file_content=("dccc.mp3")
        break
    }

    if (output_response == 6){
        cap.release()  # 释放摄像头资源
        cv2.destroyAllWindows()  # 关闭窗口
        exit()  # 彻底退出程序

    }



if __name__ == "__main__":
    main()

